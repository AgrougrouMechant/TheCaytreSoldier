#include <SDL/SDL.h>

void 				aff_vietmouss(SDL_Surface *screen, SDL_Rect pos);
void 				aff_level(SDL_Surface *screen, int map[]);
void 				aff_grille(SDL_Surface *screen);